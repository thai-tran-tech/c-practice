#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define FILENAME "log.txt"
#define MAXLENGTHFILE 5000

char fileStr[MAXLENGTHFILE];

//Function declaration
int soBanTinGuiDi(char *str);
int soBanTinTuThietBi(char *str);
int soCongTac(char *str);
int soBanTinGuiLoi(char *str);
int thoiGianTreLonNhat(char *str);
int thoiGianTreTrungBinh(char *str);

//Main to run
int main()
{
    /* XOÁ // phía trước các hàm đã được gọi để chạy hàm đó */

    // soBanTinGuiDi(fileStr);           // CAU 1
     soBanTinTuThietBi(fileStr);       // CAU 2
    // soCongTac(fileStr);               // CAU 3
     soBanTinGuiLoi(fileStr);          // CAU 4
    // thoiGianTreLonNhat(fileStr);      // CAU 5
    // thoiGianTreTrungBinh(fileStr);    // CAU 6
}



//Funtion 

//Cau 1
int soBanTinGuiDi(char *str)
{
    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    printf("\n---CAU 1: NOI DUNG CAC BAN TIN GUI DI:---\n");
    int count = 0;
    char *token = strtok(str, "\n");
    //Dem so dong gui di va in ra
    while (token != NULL)
    {
        if (strstr(token, "\"cmd\":\"set\""))
        {
            printf("%s\n", token);
            count++;
        }
        token = strtok(NULL, "\n");
    }

    printf("\n>>Tong so ban tin gui di la: %d\n\n", count);

    fclose(fp);
    fp = NULL;
    return status;
}

//Cau 2
int soBanTinTuThietBi(char *str) {
    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    int i = 0, count = 0;
    int length = strlen(str);
    int numLine = 1;
    
    //Dem so dong tin gui di va gui ve
    for (int k = 0; k <length; k++) {
        if(str[k] == '\n') numLine++;
    }

    
    //Luu cac dong tin vao chuoi splitString;
    char splitString[numLine][300];
    char *token = strtok(str, "\n");

    while (token != NULL && i < numLine)
    {
        strcpy(splitString[i], token);
        token = strtok(NULL, "\n");
        i++;
    }

    
    char inputnwk[10];
    char nwk[5];
    int countnwk = 0;
    printf("CAU 2: Nhap ten thiet bi can tim: ");
    bool found = false;

    //Nhap input ten thiet bi va kiem tra
    while (found == false) {
        scanf("%s", inputnwk);
        for (int i = 0; i < numLine; i++) {
            if (strstr(splitString[i],"\"cmd\":\"set\"")) {
                strncpy(nwk,splitString[i]+86,4);
                strcpy(nwk+4,"");
                
                //So sanh input va ten thiet bi, in ra man hinh neu tim thay
                if (strcmp(nwk,inputnwk) == 0) {
                    for (int j = 0; j < numLine; j++) {
                        if (strstr(splitString[j],"\"cmd\":\"set\"") && strstr(splitString[j],inputnwk)) {
                            printf("\n%s",splitString[j]);
                            countnwk++;
                        }
                    }
                    printf("\n\nTong tin gui di cua thiet bi \"%s\" la: %d", inputnwk, countnwk);
                    found = true;
                    break;
                }
            }  
        }

        //Bat dau lai vong lap neu khong tim thay tin thiet bi
        if (found == false) printf("\nKhong tim duoc ma thiet bi, vui long nhap lai: ");
    }

    fclose(fp);
    fp = NULL;
    return status;
}

//Cau 3
int soCongTac(char *str) {
    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    char splitString[100][300];
    int i = 0, count = 0;
    int length = strlen(str);
    int numLine = 1;

    //Dem so dong tin gui di va gui ve
    for (int k = 0; k < length; k++)
    {
        if (str[k] == '\n')
            numLine++;
    }

    //Luu cac dong tin vao chuoi splitString;
    char *token = strtok(str, "\n");

    while (token != NULL && i < numLine)
    {
        strcpy(splitString[i], token);
        token = strtok(NULL, "\n");
        i++;
    }

    printf("\n---CAU 3: SO CONG TAC: ");


    char congTac[10][2][100];
    int thietBi = 0;
    char temp[100];
    for (int i = 0; i < numLine; i++) {
        if (strstr(splitString[i],"set"))
        {
            strncpy(temp, splitString[i] + 86, 4);
            
            //Dem so cong tac
            if (strcmp(temp, congTac[thietBi-1][0])) {
                strncpy(congTac[thietBi][0], splitString[i] + 86, 4);
                strncpy(congTac[thietBi][1], splitString[i] + 93, 1);
                thietBi++;
            } else {
                continue;
            }
                
        }
    }
    

//In ket qua ra man hinh
    for (int i = 0; i < thietBi; i++) {
        printf("\nThiet bi %d co dia chi: network - %s voi ENDPOINT - %s",i+1,congTac[i][0],congTac[i][1]);
    }
    fclose(fp);
    fp = NULL;
    return status;
}

//Cau 4
int soBanTinGuiLoi(char *str)
{
    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    char splitString[100][300];
    int i = 0, count = 0;
    int length = strlen(str);
    int numLine = 1;
    
    //Dem so dong tin gui di va gui ve
    for (int k = 0; k <length; k++) {
        if(str[k] == '\n') numLine++;
    }

    
    //Luu cac dong tin vao chuoi splitString;
    char *token = strtok(str, "\n");

    while (token != NULL && i < numLine)
    {
        strcpy(splitString[i], token);
        token = strtok(NULL, "\n");
        i++;
    }

    char reqidSend[numLine][7];
    char reqidRecieve[numLine][7];
    int order = 0, countSend, countRecieve;


    //Ban tin reqid gui di
    for (int k = 0; k < numLine; k++) {
        countSend = order;
        if (strstr(splitString[k],"set")) {
            char *addressReqid = strstr(splitString[k], "reqid");
            strncpy(reqidSend[order], addressReqid+8,6);
            strncpy(reqidSend[order]+6,"",1);
            ++order;
        } else continue;
    }


    //Ban tin reqid tra ve
    order = 0;
    for (int k = 0; k < numLine; k++)
    {
        countRecieve = order;
        if (strstr(splitString[k], "status"))
        {
            char *addressReqid = strstr(splitString[k], "reqid");
            strncpy(reqidRecieve[order],addressReqid + 8,6);
            strncpy(reqidRecieve[order]+6,"",1);
            //strncpy(reqidRecieve[order],reqidRecieve[order],6);
            ++order;
        }
        else
            continue;
    }

    //So sanh 2 ban tin va dem loi
    bool compare;
    int countError = 0;
    for (int i = 0; i < countSend; i++) {
        compare = false;
        for (int j = 0; j < countRecieve; j++) {
            if (strcmp(reqidSend[i],reqidRecieve[j]) == 0){
                compare = true;
            }
        }
        
        if (compare == false) countError++;
    }

    //In ket qua ra man hinh
    printf("\nCAU 4 - So ban tin loi la: %d", countError);

    fclose(fp);
    fp = NULL;
    return status;
}

//Cau 5
int thoiGianTreLonNhat(char *str) {

    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    char splitString[100][300];
    int i = 0, count = 0;
    int length = strlen(str);
    int numLine = 1;

    //Dem so dong tin gui di va gui ve
    for (int k = 0; k < length; k++)
    {
        if (str[k] == '\n')
            numLine++;
    }

    //Luu cac dong tin vao chuoi splitString;
    char *token = strtok(str, "\n");

    while (token != NULL && i < numLine)
    {
        strcpy(splitString[i], token);
        token = strtok(NULL, "\n");
        i++;
    }

    i = 0;
    char phut[18][10];
    int phutInt[18];
    char giay[18][10];
    float giayFlo[18];
    int doTre[9];
    int max=0;

    printf("\n---CAU 5: THOI GIAN TRE LON NHAT: ");


    //Nhap so phut
    for (int i = 0; i < numLine; i++) {
        strncpy(phut[i],splitString[i]+20,2);
        phutInt[i] = atoi(phut[i]);
    }

    //Nhap so giay
    for (int i = 0; i < numLine; i++)
    {
        strncpy(giay[i], splitString[i] + 23, 6);
        giayFlo[i] = atof(giay[i]);
    }

    //printf("\n%d", phutInt[17]);
    //printf("\n%.3f", giayFlo[0]);

    char *sub;
    int j;
    char a[4][50];
    char b[4][50];

    //Tinh toan ra milisecond
    for (int i = 0; i < numLine; i += 2)
    {
        sub = strtok(splitString[i], " ");
        j = 0;
        while (sub != NULL)
        {
            strcpy(a[j], sub);
            sub = strtok(NULL, " ");
            j++;
        }

        sub = strtok(splitString[i + 1], " ");
        j = 0;
        while (sub != NULL)
        {
            strcpy(b[j], sub);
            sub = strtok(NULL, " ");
            j++;
        }

        if (strcmp(a[1], b[1]))
        {
            count++;
            continue;
        } else {
                doTre[i / 2] = (phutInt[i + 1] * 60000 + giayFlo[i + 1] * 1000) - (phutInt[i] * 60000 + giayFlo[i] * 1000);
                if (max < doTre[i / 2])
                {
                    max = doTre[i / 2];
                }
        }
    }

    
    //In ket qua
    printf("%d Milisecond", max);
    fclose(fp);
    fp = NULL;
    return status;
}

//Cau 6
int thoiGianTreTrungBinh(char *str)
{

    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL)
    {
        printf("File does not exist\n");
        return -1;
    }

    status = fread(str, MAXLENGTHFILE, 1, fp);

    char splitString[100][300];
    int i = 0, count = 0;
    int length = strlen(str);
    int numLine = 1;

    //Dem so dong tin gui di va gui ve
    for (int k = 0; k < length; k++)
    {
        if (str[k] == '\n')
            numLine++;
    }

    //Luu cac dong tin vao chuoi splitString;
    char *token = strtok(str, "\n");

    while (token != NULL && i < numLine)
    {
        strcpy(splitString[i], token);
        token = strtok(NULL, "\n");
        i++;
    }

    char phut[18][10];
    int phutInt[18];
    char giay[18][10];
    float giayFlo[18];
    int doTre[9];
    int sum = 0;

    printf("\n---CAU 6: THOI GIAN TRE TRUNG BINH: ");

    //Nhap so phut
    for (int i = 0; i < numLine; i++)
    {
        strncpy(phut[i], splitString[i] + 20, 2);
        phutInt[i] = atoi(phut[i]);
    }

    //Nhap so giay
    for (int i = 0; i < 18; i++)
    {
        strncpy(giay[i], splitString[i] + 23, 6);
        giayFlo[i] = atof(giay[i]);
    }

    //printf("\n%d", phutInt[17]);
    //printf("\n%.3f", giayFlo[0]);

    char *sub;
    int j,k=0;
    char a[4][50];
    char b[4][50];
    //Tinh toan ra milisecond
    for (int i = 0; i < 18; i += 2)
    {
        sub = strtok(splitString[i], " ");
        j = 0;
        while (sub != NULL)
        {
            strcpy(a[j], sub);
            sub = strtok(NULL, " ");
            j++;
        }

        sub = strtok(splitString[i + 1], " ");
        j = 0;
        while (sub != NULL)
        {
            strcpy(b[j], sub);
            sub = strtok(NULL, " ");
            j++;
        }

        if (strcmp(a[1], b[1]))
        {
            continue;
        }
        else
        {
            doTre[i / 2] = (phutInt[i + 1] * 60000 + giayFlo[i + 1] * 1000) - (phutInt[i] * 60000 + giayFlo[i] * 1000);
            count++;
            
        }
    }

    //Tim gia tri trung binh
    int average = 0;
    for (int i = 0; i < 9; i++) {
        if (doTre[i] >= 0 && average!= 0) {
            average = (average+doTre[i])/2;
        } else if (doTre[i] >= 0 && average == 0){
            average = doTre[i];
        }
    }

    //In ket qua
    printf("%d milisecond", average);
    fclose(fp);
    fp = NULL;
    return status;
}
