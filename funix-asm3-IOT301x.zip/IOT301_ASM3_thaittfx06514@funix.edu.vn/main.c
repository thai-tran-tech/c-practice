#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "queue.h"
#include "queue.c"
#define ROW 9
#define COL 9

#define SIZE_QUEUE_DATA_RX 256

#if (SIZE_QUEUE_DATA_RX & (SIZE_QUEUE_DATA_RX - 1)) != 0
#error "SIZE_QUEUE_DATA_RX must be power of two"
#endif

const int DATA[ROW][COL] = {{1, 1, 0, 0, 0, 1, 1, 1, 0}, {0, 1, 1, 1, 0, 1, 0, 1, 0}, {0, 0, 0, 1, 1, 1, 1, 1, 0}, {0, 1, 1, 0, 0, 0, 1, 0, 1}, {1, 1, 1, 0, 1, 0, 1, 0, 1}, {0, 1, 0, 1, 0, 0, 1, 0, 1}, {1, 0, 1, 0, 1, 0, 1, 1, 1}, {1, 0, 0, 1, 0, 1, 0, 0, 1}, {0, 1, 1, 1, 0, 1, 0, 1, 0}};

//defining point
typedef struct POINT
{
	int row;
	int col;	
} point_t;

//defining node
typedef struct NODE
{
	point_t p;
	int distance;
} node_t;

//contain a array of nodes have value is 1 (true)
node_t arrayOfNode[10000];

point_t pointDestination; //Coordinate of the destination point
node_t sourceNode = {.distance = 0}; //the source node
static buffqueue_t serialQueueRx;
static uint8_t pQueueDataRx[SIZE_QUEUE_DATA_RX];
node_t v;

// check row and col number is in range
bool isValid(int row, int col)
{
	return (row >= 0) && (row < ROW) &&
		   (col >= 0) && (col < COL);
}

// These arrays are used to get row and column
// numbers of 4 neighbours of a given cell
int rowNum[] = {-1, 0, 0, 1};
int colNum[] = {0, -1, 1, 0};

/*Declaring function*/
int kiemTraToaDo();
int timCacDiemXungQuanh();
int quangDuongNganNhat();


int main() 
{	
	//Cau 1
	kiemTraToaDo();

	//Cau 2
	timCacDiemXungQuanh();

	//Cau 3
	int result3 = quangDuongNganNhat();
	if (result3 != -1){
		printf("Quang duong ngan nhat tim duoc la: %d buoc", result3);
	} else printf("Khong tim duoc duong di");

	return 0;
}


/* kiemTraToaDo() function
	Check if the entered coordinate exist or not
*/
int kiemTraToaDo()
{
	printf("\nCAU 1: KIEM TRA TOA DO\n");

	//Input from user
	struct POINT input;
	printf("Nhap toa do can kiem tra:\n");
	printf("x = ");
	scanf("%d",&input.col);
	printf("y = ");
	scanf("%d", &input.row);

	/*Check and print out the result*/
	if (input.col < COL && input.row < ROW && input.col >=0 && input.row >=0)
	{
		printf(">>Toa do (%d,%d) co gia tri la %d",input.col,input.row,DATA[input.col][input.row]);
	}
	else
		printf(">>Toa do (%d,%d) khong ton tai", input.col, input.row);

	return 0;
}

/* timCacDiemXungQuanh() function
	Find values of coordinates around the entered coordinate
*/
int timCacDiemXungQuanh() 
{
	printf("\n\nCAU 2: TIM GIA TRI TOA DO DIEM XUNG QUANH\n");

	//Nhap toa do can kiem tra
	struct POINT input;
	printf("Nhap toa do can kiem tra:\n");
	while (0!=1) {
		printf("x = ");
		scanf("%d", &input.col);
		printf("y = ");
		scanf("%d", &input.row);

		if (input.col < COL && input.row < ROW && input.col >= 0 && input.row >= 0)
		{
			//Bien gia tri cac toa do xung quanh
			int leftPoint, abovePoint, rightPoint, belowPoint;

			leftPoint = DATA[input.col - 1][input.row];
			abovePoint = DATA[input.col][input.row - 1];
			rightPoint = DATA[input.col + 1][input.row];
			belowPoint = DATA[input.col][input.row + 1];

			//Gia tri diem ben trai 
			printf("Gia tri diem ben trai la: ");
			if (input.col != 0) {
				printf("%d\n", leftPoint);
			} else printf("khong ton tai\n");

			//Gia tri diem ben tren
			printf("Gia tri diem ben tren la: ");
			if (input.row != 0)
			{ 
				printf("%d\n", abovePoint);
			}
			else printf("khong ton tai\n");

			//Gia tri diem ben phai
			printf("Gia tri diem ben phai la: ");
			if (input.col != 8)
			{
				printf("%d\n", rightPoint);
			}
			else printf("khong ton tai\n");

			//Gia tri diem ben duoi
			printf("Gia tri diem ben duoi la: ");
			if (input.row != 8)
			{
				printf("%d\n", belowPoint);
			}
			else printf("khong ton tai\n");

			break;
		} else {
			printf("Toa do khong ton tai, vui long nhap lai:\n");
			continue;
		}
	}

	return 0;
}

/* quangDuongNganNhat() function
	Find the shortest distance from (0,0) to the entered coordinate
*/
int quangDuongNganNhat(){
	printf("\n\nCAU 3: TIM QUANG DUONG NGAN NHAT\n");

	//Input from user, "sourceNode" and "pointDestination"
	while (0!=1) {
		printf("Nhap diem bat dau: \nx = ");
		scanf("%d", &sourceNode.p.row);
		printf("y = ");
		scanf("%d", &sourceNode.p.col);
		printf("Nhap dich den: \nx = ");
		scanf("%d", &pointDestination.row);
		printf("y = ");
		scanf("%d", &pointDestination.col);
		if (isValid(sourceNode.p.row,sourceNode.p.col) && isValid(pointDestination.row,pointDestination.col)) break;
		printf("\nToa do nhap vao nam vao gioi han ma tran, vui long nhap lai: \n");
	}

	bufInit(pQueueDataRx, &serialQueueRx, sizeof(node_t), SIZE_QUEUE_DATA_RX);
	if (!DATA[sourceNode.p.row][sourceNode.p.row] || !DATA[pointDestination.row][pointDestination.col]){
		return -1;
	}

	bool visited[ROW][COL];
	for (int x = 0; x < ROW; x++) {
		for (int y = 0; y < COL; y++) {
			visited[x][y] = false;
		}
	}
	// Mark the source cell as visited
	visited[sourceNode.p.row][sourceNode.p.col] = true;

	//ENQUEUE source node
	bufEnDat(&serialQueueRx, (uint8_t *)&sourceNode);
	
	int arrayOrder = 0;
	int a = 1;
	arrayOfNode[0] = sourceNode;

	while (bufNumItems(&serialQueueRx) != 0)
	{
		node_t curr = arrayOfNode[arrayOrder];
		arrayOrder++;
		point_t checkPoint = curr.p;

		// If we have reached the destination cell,
		// we are done
		if (checkPoint.row == pointDestination.row && checkPoint.col == pointDestination.col)
			return curr.distance;

		bufDeDat(&serialQueueRx, (uint8_t *)&v);

		for (int i = 0; i < 4; i++)
		{
			int row = checkPoint.row + rowNum[i];
			int col = checkPoint.col + colNum[i];

			// if adjacent cell is valid, has path and
			// not visited yet, enqueue it.
			if (isValid(row, col) && DATA[row][col] == 1 &&
				visited[row][col] != true)
			{
				// mark cell as visited and enqueue it
				visited[row][col] = true;
				node_t Adjcell = {{row, col},
									curr.distance + 1};
				arrayOfNode[a] = Adjcell;
				a++;
				bufEnDat(&serialQueueRx, (uint8_t *)&Adjcell);
			}
		}
	}
	return -1;
}
