#include <stdio.h>
#include <math.h>
#define PI 3.14159265359

int i = 0;

void giaiMaTamGiac(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{
    double canhAB, canhBC, canhAC, gocA, gocB, gocC, ha, hb, hc, S, Tx, Ty, Ma, Mb, Mc, Gx, Gy;

    //TINH TOAN CAC THAM SO
    canhAB = sqrt(pow(Ax - Bx, 2) + pow(Ay - By, 2));
    canhAC = sqrt(pow(Ax - Cx, 2) + pow(Ay - Cy, 2));
    canhBC = sqrt(pow(Cx - Bx, 2) + pow(Cy - By, 2));

    gocA = acos((pow(canhAB, 2) + pow(canhAC, 2) - pow(canhBC, 2)) / (2 * canhAC * canhAB)) * 180 / PI;
    gocB = acos((pow(canhAB, 2) + pow(canhBC, 2) - pow(canhAC, 2)) / (2 * canhBC * canhAB)) * 180 / PI;
    gocC = acos((pow(canhBC, 2) + pow(canhAC, 2) - pow(canhAB, 2)) / (2 * canhAC * canhBC)) * 180 / PI;

    S = canhBC * canhAB * sin(gocB * PI / 180) / 2;

    ha = 2 * S / canhBC;
    hb = 2 * S / canhAC;
    hc = 2 * S / canhAB;
    Ma = sqrt(pow(Ax - (Bx + Cx) / 2, 2) + pow(Ay - (By + Cy) / 2, 2));
    Mb = sqrt(pow(Bx - (Cx + Ax) / 2, 2) + pow(By - (Cy + Ay) / 2, 2));
    Mc = sqrt(pow(Cx - (Ax + Bx) / 2, 2) + pow(Cy - (Ay + By) / 2, 2));

    Tx = (Ax + Bx + Cx);
    Ty = (Ay + By + Cy);
    Gx = Tx / 3;
    Gy = Ty / 3;

    //IN KET QUA
    if (canhAB >= canhAC + canhBC || canhBC >= canhAC + canhAB || canhAC >= canhAB + canhBC)
    {
        printf("Toa do 3 diem khong the tao thanh tam giac (false)\n");
        printf("VUI LONG NHAP LAI TOA DO:\n");
        i = 0;
    }
    else
    {
        printf("Toa do 3 diem tao thanh mot tam giac (true)\n\n");
        printf("1. So do co ban cua tam giac:\n");
        printf("   Do dai canh AB:");
        printf("%0.2f", canhAB);
        printf("\n");
        printf("   Do dai canh AC:");
        printf("%0.2f", canhAC);
        printf("\n");
        printf("   Do dai canh BC:");
        printf("%0.2f", canhBC);
        printf("\n");
        printf("   Goc A          :");
        printf("%0.2f", gocA);
        printf("\n");
        printf("   Goc B          :");
        printf("%0.2f", gocB);
        printf("\n");
        printf("   Goc C          :");
        printf("%0.2f", gocC);

        //XET TAM GIAC
        printf("\n\n");
        if (canhAB == canhAC == canhBC)
        {
            printf("Tam giac ABC la tam giac deu");
        }
        else if (canhAB == canhAC || canhAB == canhBC || canhBC == canhAC)
        {
            if (canhAB == canhAC)
            {
                if (gocA < 90.001 && gocA > 89.999)
                {
                    printf("Tam giac vuong can tai A");
                }
                else if (gocA > 90)
                {
                    printf("Tam giac tu can tai A");
                }
                else
                {
                    printf("Tam giac can tai A");
                }
            }
            else if (canhAB == canhBC)
            {
                if (gocB < 90.001 && gocB > 89.999)
                {
                    printf("Tam giac vuong can tai B");
                }
                else if (gocB > 90)
                {
                    printf("Tam giac tu can tai B");
                }
                else
                {
                    printf("Tam giac can tai B");
                }
            }
            else
            {
                if (gocC < 90.001 && gocC > 89.999)
                {
                    printf("Tam giac vuong can tai C");
                }
                else if (gocC > 90)
                {
                    printf("Tam giac tu can tai C");
                }
                else
                {
                    printf("Tam giac can tai C");
                }
            }
        }
        else
        {
            if (gocA < 90.001 && gocA > 89.999)
            {
                printf("Tam giac vuong tai A");
            }
            else if (gocB < 90.001 && gocB > 89.999)
            {
                printf("Tam giac vuong tai B");
            }
            else if (gocC < 90.001 && gocC > 89.999)
            {
                printf("Tam giac vuong tai C");
            }
            else if (gocA > 90)
            {
                printf("Tam giac tu tai A");
            }
            else if (gocB > 90)
            {
                printf("Tam giac tu tai B");
            }
            else if (gocC > 90)
            {
                printf("Tam giac tu tai C");
            }
            else
            {
                printf("Tam giac thuong");
            }
        }

        printf("\n2.  Dien tich tam giac: %0.2f\n\n", S);
        printf("3. So do nang cao tam giac:\n");
        printf("  Do dai duong cao tu dinh A: %0.2f\n", ha);
        printf("  Do dai duong cao tu dinh B: %0.2f\n", hb);
        printf("  Do dai duong cao tu dinh C: %0.2f\n", hc);
        printf("  Do dai duong trung tuyen tu dinh A: %0.2f\n", Ma);
        printf("  Do dai duong trung tuyen tu dinh B: %0.2f\n", Mb);
        printf("  Do dai duong trung tuyen tu dinh C: %0.2f\n\n", Mc);

        printf("4. Toa do trong tam tam giac ABC la G(%0.2f,%0.2f)", Gx, Gy);

        i = 1;
    }
}


    

    int main()
    {
        printf("NHAP TOA DO CAC DIEM TAM GIAC:\n");
        float Ax, Ay, Bx, By, Cx, Cy;
        while (i == 0)
        {
            //INPUT
            printf("Nhap toa do diem A:\nAx: ");
            scanf("%f", &Ax);
            printf("Ay: ");
            scanf("%f", &Ay);
            printf("\n");

            printf("Nhap toa do diem B:\nBx: ");
            scanf("%f", &Bx);
            printf("By: ");
            scanf("%f", &By);
            printf("\n");

            printf("Nhap toa do diem CA:\nCx: ");
            scanf("%f", &Cx);
            printf("Cy: ");
            scanf("%f", &Cy);
            printf("\n");
            printf("Toa do diem A: A(%0.2f,%0.2f)\n", Ax, Ay);
            printf("Toa do diem B: B(%0.2f,%0.2f)\n", Bx, By);
            printf("Toa do diem C: C(%0.2f,%0.2f)\n", Cx, Cy);
            printf("----------------------------------\n");
            //Kiem tra tam giac
            giaiMaTamGiac(Ax, Ay, Bx, By, Cx, Cy);
        }
    }