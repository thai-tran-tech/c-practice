#include <stdio.h>
#include <math.h>
#define PI 3.14159265359

int i = 0;
int kiemTraTamGiac(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{

    double canhAB, canhBC, canhAC;
    canhAB = sqrt(pow(Ax - Bx, 2) + pow(Ay - By, 2));
    canhAC = sqrt(pow(Ax - Cx, 2) + pow(Ay - Cy, 2));
    canhBC = sqrt(pow(Cx - Bx, 2) + pow(Cy - By, 2));

    if (canhAB >= canhAC + canhBC || canhBC >= canhAC + canhAB || canhAC >= canhAB + canhBC)
    {
        printf("Toa do 3 diem khong the tao thanh tam giac (false)\n");
        printf("VUI LONG NHAP LAI TOA DO:\n");
        i = 0;
    }
    else
    {
        printf("Toa do 3 diem tao thanh mot tam giac (true)\n\n");
        i = 1;
    }

    return 0;
}

void xetTamGiac(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{
    double canhAB, canhBC, canhAC, gocA, gocB, gocC;
    canhAB = sqrt(pow(Ax - Bx, 2) + pow(Ay - By, 2));
    canhAC = sqrt(pow(Ax - Cx, 2) + pow(Ay - Cy, 2));
    canhBC = sqrt(pow(Cx - Bx, 2) + pow(Cy - By, 2));

    gocA = acos((pow(canhAB, 2) + pow(canhAC, 2) - pow(canhBC, 2)) / (2 * canhAC * canhAB)) * 180 / PI;
    gocB = acos((pow(canhAB, 2) + pow(canhBC, 2) - pow(canhAC, 2)) / (2 * canhBC * canhAB)) * 180 / PI;
    gocC = acos((pow(canhBC, 2) + pow(canhAC, 2) - pow(canhAB, 2)) / (2 * canhAC * canhBC)) * 180 / PI;

    printf("1. So do co ban tam giac:\n");
    printf("   Do dai canh AB:");
    printf("%0.2f", canhAB);
    printf("\n");
    printf("   Do dai canh AC:");
    printf("%0.2f", canhAC);
    printf("\n");
    printf("   Do dai canh BC:");
    printf("%0.2f", canhBC);
    printf("\n");
    printf("   Goc A          :");
    printf("%0.2f", gocA);
    printf("\n");
    printf("   Goc B          :");
    printf("%0.2f", gocB);
    printf("\n");
    printf("   Goc C          :");
    printf("%0.2f", gocC);

    //XET TAM GIAC
    printf("\n\n");
    if (canhAB == canhAC == canhBC)
    {
        printf("Tam giac ABC la tam giac deu");
    }
    else if (canhAB == canhAC || canhAB == canhBC || canhBC == canhAC)
    {
        if (canhAB == canhAC)
        {
            if (gocA < 90.001 && gocA > 89.999)
            {
                printf("Tam giac vuong can tai A");
            }
            else if (gocA > 90)
            {
                printf("Tam giac tu can tai A");
            }
            else
            {
                printf("Tam giac can tai A");
            }
        }
        else if (canhAB == canhBC)
        {
            if (gocB < 90.001 && gocB > 89.999)
            {
                printf("Tam giac vuong can tai B");
            }
            else if (gocB > 90)
            {
                printf("Tam giac tu can tai B");
            }
            else
            {
                printf("Tam giac can tai B");
            }
        }
        else
        {
            if (gocC < 90.001 && gocC > 89.999)
            {
                printf("Tam giac vuong can tai C");
            }
            else if (gocC > 90)
            {
                printf("Tam giac tu can tai C");
            }
            else
            {
                printf("Tam giac can tai C");
            }
        }
    }
    else
    {
        if (gocA < 90.001 && gocA > 89.999)
        {
            printf("Tam giac vuong tai A");
        }
        else if (gocB < 90.001 && gocB > 89.999)
        {
            printf("Tam giac vuong tai B");
        }
        else if (gocC < 90.001 && gocC > 89.999)
        {
            printf("Tam giac vuong tai C");
        }
        else if (gocA > 90)
        {
            printf("Tam giac tu tai A");
        }
        else if (gocB > 90)
        {
            printf("Tam giac tu tai B");
        }
        else if (gocC > 90)
        {
            printf("Tam giac tu tai C");
        }
        else
        {
            printf("Tam giac thuong");
        }
    }
}

void dienTichTamGiac(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{
    double canhAB, canhBC, canhAC, gocB, S;
    canhAB = sqrt(pow(Ax - Bx, 2) + pow(Ay - By, 2));
    canhBC = sqrt(pow(Cx - Bx, 2) + pow(Cy - By, 2));
    canhAC = sqrt(pow(Ax - Cx, 2) + pow(Ay - Cy, 2));

    gocB = acos((pow(canhAB, 2) + pow(canhBC, 2) - pow(canhAC, 2)) / (2 * canhBC * canhAB)) * 180 / PI;

    S = canhBC * canhAB * sin(gocB * PI / 180) / 2;
    printf("\n\n2. Dien tich tam giac: %0.2f", S);
}

void duongCao(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{
    //Tinh toan
    double canhAB, canhBC, canhAC, gocB, S, ha, hb, hc;
    canhAB = sqrt(pow(Ax - Bx, 2) + pow(Ay - By, 2));
    canhBC = sqrt(pow(Cx - Bx, 2) + pow(Cy - By, 2));
    canhAC = sqrt(pow(Ax - Cx, 2) + pow(Ay - Cy, 2));

    gocB = acos((pow(canhAB, 2) + pow(canhBC, 2) - pow(canhAC, 2)) / (2 * canhBC * canhAB)) * 180 / PI;
    S = canhBC * canhAB * sin(gocB * PI / 180) / 2;
    ha = 2 * S / canhBC;
    hb = 2 * S / canhAC;
    hc = 2 * S / canhAB;

    printf("\n\n");
    printf("3. So do nang cao tam giac:\n");
    printf("  Do dai duong cao tu dinh A: %0.2f\n", ha);
    printf("  Do dai duong cao tu dinh B: %0.2f\n", hb);
    printf("  Do dai duong cao tu dinh C: %0.2f\n", hc);
}

void trungTuyen(int Ax, int Ay, int Bx, int By, int Cx, int Cy)
{
    double Ma, Mb,Mc;

    Ma = sqrt(pow(Ax - (Bx + Cx) / 2, 2) + pow(Ay - (By + Cy) / 2, 2));
    Mb = sqrt(pow(Bx - (Cx + Ax) / 2, 2) + pow(By - (Cy + Ay) / 2, 2));
    Mc = sqrt(pow(Cx - (Ax + Bx) / 2, 2) + pow(Cy - (Ay + By) / 2, 2));

   
    printf("  Do dai duong trung tuyen tu dinh A: %0.2f\n", Ma);
    printf("  Do dai duong trung tuyen tu dinh B: %0.2f\n", Mb);
    printf("  Do dai duong trung tuyen tu dinh C: %0.2f\n", Mc);

}

int main()
{
    printf("NHAP TOA DO CAC DIEM TAM GIAC:\n");
    float Ax, Ay, Bx, By, Cx, Cy;
    while (i == 0)
    {

        printf("Nhap toa do diem A:\nAx: ");
        scanf("%f", &Ax);
        printf("Ay: ");
        scanf("%f", &Ay);
        printf("\n");

        printf("Nhap toa do diem B:\nBx: ");
        scanf("%f", &Bx);
        printf("By: ");
        scanf("%f", &By);
        printf("\n");

        printf("Nhap toa do diem CA:\nCx: ");
        scanf("%f", &Cx);
        printf("Cy: ");
        scanf("%f", &Cy);
        printf("\n");
        printf("Toa do diem A: A(%f,%f)\n", Ax, Ay);
        printf("Toa do diem B: B(%f,%f)\n", Bx, By);
        printf("Toa do diem C: C(%f,%f)\n", Cx, Cy);
        printf("----------------------------------\n");
        //Kiem tra tam giac
        kiemTraTamGiac(Ax, Ay, Bx, By, Cx, Cy);
    }

    xetTamGiac(Ax, Ay, Bx, By, Cx, Cy);
    dienTichTamGiac(Ax, Ay, Bx, By, Cx, Cy);
    duongCao(Ax, Ay, Bx, By, Cx, Cy);
    trungTuyen(Ax, Ay, Bx, By, Cx, Cy);
}